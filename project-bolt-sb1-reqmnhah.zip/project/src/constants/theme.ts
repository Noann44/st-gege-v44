export const COLORS = {
  primary: '#00f5ff', // Cyan futuriste
  secondary: '#ff00ff', // Magenta futuriste
  background: '#0a0b1e', // Bleu très foncé
  surface: '#161832', // Bleu foncé
  text: '#ffffff',
  textSecondary: '#b8b8d0',
};